package com.flight_reservation_app.services;

import com.flight_reservation_app.entities.User;

public interface UserService {
	
	public void saverecord(User user);
    
	
}
